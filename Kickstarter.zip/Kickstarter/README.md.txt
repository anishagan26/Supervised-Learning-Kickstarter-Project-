>To run this dataset, download the jupyter notebook file from Blackboard.

>Install Anaconda or $ pip install notebook on the comand prompt

>Launch with from local:

$ jupyter notebook

>Download the dataset from https://www.kaggle.com/kemical/kickstarter-projects

> Run all the cells from the notebook

For further information about ANACONDA and JUPYTER NOTEBOOK, check out the DOCS.